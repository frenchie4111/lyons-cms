<?php
$open = true;
include_once( "connect.php" );
logout();
header( "Location: index.php" );
?>
